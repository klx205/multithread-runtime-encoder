//
//  nyuenc.c
//  
//
//  Created by Kevin Xiong on 11/9/23.
//
//MILESTONE 1 DONE, NEXT READ THREADS SLIDES AND DO MILESTONE 2, 60% ACHIEVED

#include "nyuenc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <getopt.h>
#include <stdbool.h>
#include <ctype.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <errno.h> 
#include <fcntl.h> 

#define CHUNK 4096 // 4kb chunks

/*
Plan is to parse the data files, recognize each and somehow divide into 4kb chunks
Then, each chunk is a task, and each task is enqueued into a queue
Then, each thread will dequeue a task, process it, and then write to resultsArray
Stitching should be done after all processing by the main thread, writing to stdout

NEWEST: MAYBE I CAN IMPLEMENT THREADRESULTS WITH A NEW QUEUE SO THE MAIN THREAD CAN PARALLELIZE
*/

//track through my code, 

//Task_structure
typedef struct {
    char *data;
    size_t size;
    int order;
    unsigned char * encoded;
}Task;

//Node
typedef struct Node{
    Task *task;
    struct Node *next;
} Node;

//Queue 
typedef struct Queue{
    Node *head;
    Node *tail;
    pthread_mutex_t mutex;
    pthread_cond_t cond;
} Queue;

//Double queue
typedef struct DoubleQueue{
    Queue *queue;
    Queue *doneQueue;
} DoubleQueue;

//static global variable to keep track of count
static int order = 0;

//mutex for order
pthread_mutex_t orderMutex = PTHREAD_MUTEX_INITIALIZER;

//Enqueue
void enqueueTask(Queue *queue, Task *task){
    if (task == NULL){
        perror("NULL TASK");
        exit(0);
    }
    Node *node = malloc(sizeof(Node));

    if (node == NULL){
        perror("malloc in enqueue");
        exit(0);
    }

    node->task = task;
    node->next = NULL;

    if (task->order == -1){
        pthread_mutex_lock(&orderMutex);
        node->task->order = order++;
        //printf("assigned order in enqueue as %d\n", node->task->order);
        pthread_mutex_unlock(&orderMutex);
    }
    
    pthread_mutex_lock(&queue->mutex);

    if (queue->tail != NULL){
        queue->tail->next = node;
    }

    queue->tail = node;

    if(queue->head == NULL){
        queue->head = node;
    }
    
    pthread_cond_signal(&queue->cond);
    pthread_mutex_unlock(&queue->mutex);
    //printf("finishes enqueue\n");
}

//Dequeue

Task* dequeueTask(Queue *queue){
    //printf("thread %ld entered dequeue\n", pthread_self());
    pthread_mutex_lock(&queue->mutex);
    if (queue->head == NULL) {
        //printf("head is null so i unlock , thread %ld, and return null\n", pthread_self());
        pthread_mutex_unlock(&queue->mutex);
        return NULL;
    }

    Node *node = queue->head;

    Task *task = node->task;

    queue->head = node->next;

    if (queue->head == NULL){
        queue->tail = NULL;
    }else{
        node->next = NULL;
    }

   //printf("before task dequeue, task %d, thread %ld\n", task->order, pthread_self());

    //printf("Task %d dequeued\n", task->order);
    pthread_mutex_unlock(&queue->mutex);

    free(node);
    return task;
}

//Queue Init
void initializeQueue(Queue *queue){
    queue->head = NULL;
    queue->tail = NULL;
    pthread_mutex_init(&queue->mutex, NULL);
    pthread_cond_init(&queue->cond, NULL);
}

//Queue Destroy
void destroy(DoubleQueue *doubleQueue){
    Queue *queue = doubleQueue->queue;
    Queue * doneQueue = doubleQueue->doneQueue;
    Node *node = queue->head;


    while(node != NULL){
        Node *temp = node->next;
        //printf("freeing node\n");
        free(node);
        node = temp;
    }
    
    
    Node *doneNode = doneQueue->head;
    while(doneNode != NULL){
        Node *temp = doneNode->next;
        //printf("freeing doneNode\n");
        free(doneNode);
        doneNode = temp;
    }
    
    //free(queue);
    //free(doneQueue);
    
}

//task processing
Task* processTask(Task *task){
    //encode task
    //printf("Entered processTask\n");
    char *data = task->data;

    //worst case is encoded twice with count, so size * 2
    unsigned char* encoded = malloc(task->size * 2);
    memset(encoded, 0, task->size*2);
    if(encoded == NULL){
        perror("malloc in processTask");
        exit(0);
    }

    size_t index = 0;
    //printf("set task size to 0, task size is %ld\n", task->size);

    //Parser set to first character, count init to one
    //printf("task data is %s\n", task->data);
    char parser = task->data[0];
    unsigned int count = 1;

    for (size_t i =1; i<task->size; i++){
        char temp = data[i];

        if (temp== parser){
            count++;
        }else{
            //writes to buffer, updates encodedIndex based on parser+count char number
            encoded[index++] = parser;
            encoded[index++] =  (unsigned char) count;
            parser = temp;
            count = 1;
        }
        //printf("encoded is %s, task size is %ld\n", encoded, task->size);
    }


    //HAS TO BE A CHECK FOR THIS, IF NOT THEN IT WILL NOT WRITE THE LAST CHARACTERN
    encoded[index++] = parser;
    encoded[index++] =  (unsigned char) count;

    //printf("final encoded is %s, task size is %ld\n", encoded, task->size);
    unsigned char * tempAlloc = realloc(encoded, index);
    if (tempAlloc == NULL){
        perror("realloc");
        free(encoded);
        exit(0);
    }
    //printf("task %d is encoded and size of %ld\n", task->order, task->size);
    task->encoded = tempAlloc;
    if (munmap(task->data, task->size)){
        perror("munmap");
        exit(0);
    }
    //printf("unmapped and data is %s\n", task->encoded);
    task->size = index;
    //update result
    //printf("task %d encoded is %s\n", task->order, task->encoded);

    return task;
    }

//Encode
void * encode(void * arg){
    DoubleQueue *doubleQueue = (DoubleQueue *) arg;
    Queue *queue = doubleQueue->queue;
    Queue *doneQueue = doubleQueue->doneQueue;
    while(true){
        //printf("Entered queue loop as thread %ld\n", pthread_self());
        
        Task *task = dequeueTask(queue);

        if (task == NULL){
            continue;
        }
        //printf("retrieved task %d, I am thread %ld\n", task->order, pthread_self());
        //encode task

        task = processTask(task);
        //printf("finished encoding task%d, i am thread %ld\n", task->order, pthread_self());
        
        //printf("requeueing task %d, i am thread %ld\n", task->order, pthread_self());
        //printf("before enqueuing task %d, i am thread %ld\n", task->order, pthread_self());
        enqueueTask(doneQueue, task);
        //printf("finished requeueing task %d, i am thread %ld\n", task->order, pthread_self());
    }
    return NULL;
}


//Queue Load
void populateQueue(Queue *queue, char *filename[],int numFiles){
    for (int i = 0; i < numFiles; i++){
        int fd = open(filename[i], O_RDONLY);
        //printf("opened file \n");
        if (fd==-1){
            perror("fopen");
            exit(1);
        }
        struct stat st;
        //printf("Entered populate queue, opened file %s\n", filename[i]);
        fstat(fd, &st);
        size_t numChunks = st.st_size / CHUNK;
        size_t rem = st.st_size % CHUNK;
        //printf("numChunks id %ld, for a file size %ld\n", numChunks, st.st_size);
        for (size_t j = 0; j < numChunks; j++){
            Task *task = malloc(sizeof(Task));
            if (task== NULL){
                perror("malloc task in populate queue");
                exit(0);
            }
            task->size = 0;
            task->order = -1;
            task->data = mmap(NULL, CHUNK, PROT_READ, MAP_PRIVATE, fd, j*CHUNK);
            task->size = CHUNK;
            //printf("mapped task\n");
            
            //printf("before enqueuing task\n");
            enqueueTask(queue, task);
            //printf("enqueued task\n");
        }
        if (rem){
            Task * task = malloc(sizeof(Task));
            task->size = rem;
            task->order = -1;
            task->data = mmap(NULL, rem, PROT_READ, MAP_PRIVATE, fd, numChunks*CHUNK);
            //printf("mapped task: %s\n", task->data);
            if (task->data[task->size-1] == '\n'){
                //printf("newline found\n");
                task->size--;
            }
            enqueueTask(queue, task);
        }
    }

    //printf("populated queue with first file division\n");
    return;
}

void stitch(Queue * queue, unsigned char ** stitched, size_t *encodedLens){ //REDO FOR REQUEUE IMPLEMENTATION
    int count = 0;
    //printf("entering stitch\n");
    //printf("order is %d\n", order);
    while (count<(order)){
        //printf("Entered stitch loop\n");

        Task *task = dequeueTask(queue);

        if (task == NULL){
            continue;
        }

        //stitching
        unsigned char* current = task->encoded;
        count++;
        size_t len = task->size;
        stitched[task->order] = current;
        encodedLens[task->order] = len;
        free(task);
        task = NULL;
    }


    return;
}


int main(int argc, char * argv[]){
    
    //jobs/threads
    int opt;
    int numJobs = 1; //Sequential by default
    //printf("hello world\n");

    //parallel with threads
    if((opt = getopt(argc,argv, "j:"))!= -1){
        //prepare numFiles/tasks to initialize results array and file organization
        int numFiles = argc - optind;
        char * files[numFiles]; 


        //if j is specified, then set numJobs to the number of jobs specified
        numJobs = atoi(optarg);
        pthread_t threads[numJobs];

        //create queue
        Queue *queue = malloc(sizeof(Queue));
        Queue *doneQueue = malloc(sizeof(Queue));
        if (queue == NULL|| doneQueue == NULL){
            perror("malloc in queues");
            exit(0);
        }
        initializeQueue(queue);
        initializeQueue(doneQueue);
        DoubleQueue *doubleQueue = malloc(sizeof(DoubleQueue));
        if (doubleQueue == NULL){
            perror("malloc in doublequeue");
            exit(0);
        }
        doubleQueue->queue = queue;
        doubleQueue->doneQueue = doneQueue;
        //printf("init queues\n");

        //create threads
        for (int i = 0; i < numJobs; i++){
            //printf("creating thread %d\n", i);
            if (pthread_create(&threads[i], NULL, encode, doubleQueue)!= 0){
                perror("pthread_create");
                exit(0);
            }
        }

        //parse input data
        for (int i = 0; i< numFiles; i++){
            files[i] = argv[optind+i];
        }
        //printf("Before double Queue sent to populate\n");
        populateQueue(doubleQueue->queue, files, numFiles); 

        unsigned char* stitched[order];
        size_t encodedLens[order];
        //printf("Before stitch\n");
        stitch(doubleQueue->doneQueue, stitched, encodedLens);
    
        for (int i = 0; i < order-1; i++){
            if (stitched[i][encodedLens[i]-2] == stitched[i+1][0]){
                memset(stitched[i+1]+1, stitched[i+1][1] + stitched[i][encodedLens[i]-1], 1);
                memset(stitched[i]+encodedLens[i]-2,  0,1);
                memset(stitched[i]+encodedLens[i]-1, 0,1);
                encodedLens[i]-=2;
            } 
        }
        for (int i = 0; i<order;i++){
            if (encodedLens[i]>1){
                fwrite(stitched[i],encodedLens[i],1,stdout);
            }
        }

        //clean memory
        destroy(doubleQueue);
        free(doubleQueue);

        return 0;
    }


    //SEQUENTIAL!!!!

    //FULLY BUFFER INITALIZED -> GOOD EFFICIENCY, IMPLEMENTATION BETWEEN PRINT/WRITE
    char buffer[8192];
    
    //ERROR CHECK FOR BUFF
    if (setvbuf(stdout, buffer, _IOFBF, sizeof(buffer)) != 0) {
            fprintf(stderr, "Failed to set fully buffered mode for stdout\n");
            return 1;
    }


    //Stack init of parser and count, maybe not that necessary but who cares
    int parser;
    unsigned int count;
    
    //Stack init of lastChar tracker and lastCount tracker, very necessary
    int lastChar = EOF;
    unsigned int lastCount = 0;
    
    //ENTER LOOP
    for (int index = 1; index<argc; index++){
        //Sequential Iteration over input files
        FILE * filePtr = fopen(argv[index],"r");
        
        //Error check for file pointer
        if (!filePtr){
            fprintf(stderr, "fopen failed for input file");
            return 1;
        }
        
        //Parser set to first character, count init to one
        parser = fgetc(filePtr);
        count = 1;
        
        
        //Checks if lastChar of previous input file should be merged with next, good
        if (lastChar != EOF){
            //If its not the first run, checks the merge
            if (lastChar == parser){
                count += lastCount;
            }
            else{
                //If chars are not the same, print to buffer
                fwrite(&lastChar,sizeof(lastChar),1,stdout);
                unsigned char countByte = (unsigned char) lastCount;
                fwrite(&countByte, sizeof(countByte), 1, stdout);
            }
        }
        
        //Starts parsing through the document, iterating over temp
        int temp;
        do{
            temp = fgetc(filePtr);
            
            //If temp isn't end of file and is the same char, then increment
            if (temp!= EOF && parser == temp){
                count++;
            }
            //If temp is EOF
            else if (temp == EOF){
                //Write to buffer if it is last input file
                if ((index +1) == argc){
                    printf("%c",(unsigned char) parser);
                    unsigned char countByte = (unsigned char) count;
                    fwrite(&countByte, sizeof(countByte), 1, stdout);
                }
                //Else keep track of the last values
                else{
                    lastChar = parser;
                    lastCount = count;
                }
            }
            else {
                //If temp has switched characters from the parser
                printf("%c",(unsigned char) parser);
                unsigned char countByte = (unsigned char) count;
                fwrite(&countByte, sizeof(countByte), 1, stdout);
                parser = temp;
                count = 1;
            }
        } while (temp!= EOF);
        
        
        //Closes the file pointers at the end of each iteration
        fclose(filePtr);
    }
    
}
